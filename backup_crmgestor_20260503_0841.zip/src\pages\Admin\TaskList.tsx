import React, { useState, useEffect } from "react";
import { supabase } from "../../lib/supabase";
import { Task, Cliente } from "../../types";
import { 
  Plus, 
  Trash2, 
  Calendar as CalendarIcon, 
  User, 
  Search, 
  X, 
  Edit2, 
  ChevronRight, 
  ChevronLeft,
  Clock,
  Filter,
  AlertTriangle
} from "lucide-react";
import { cn } from "../../lib/utils";
import { format, isPast, parseISO, isValid } from "date-fns";
import { ptBR } from "date-fns/locale";

/**
 * Converte qualquer formato de data do banco para 'yyyy-MM-dd'.
 * Trata ISO com timezone, datas simples, etc.
 */
function safeToInputDate(dateStr: string | null | undefined): string {
  if (!dateStr) return format(new Date(), "yyyy-MM-dd");
  try {
    // Remove a parte de tempo se existir (2025-04-24T03:00:00+00:00 → 2025-04-24)
    const datePart = dateStr.split('T')[0];
    if (/^\d{4}-\d{2}-\d{2}$/.test(datePart)) return datePart;
    // Fallback: tenta parseISO completo
    const parsed = parseISO(dateStr);
    if (isValid(parsed)) return format(parsed, "yyyy-MM-dd");
  } catch {}
  return format(new Date(), "yyyy-MM-dd");
}

/**
 * Exibe data no formato dd/MM de forma segura.
 */
function safeFormatDate(dateStr: string | null | undefined): string {
  if (!dateStr) return "Sem data";
  try {
    const datePart = dateStr.split('T')[0];
    const parsed = parseISO(datePart);
    if (isValid(parsed)) return format(parsed, "dd/MM", { locale: ptBR });
  } catch {}
  return "Data inválida";
}
import { motion, AnimatePresence } from "motion/react";
import { Toast } from "../../components/ui/Toast";
import { logActivity } from "../../lib/activityLog";
import { useAuth } from "../../context/AuthContext";

export default function TaskList() {
  const { user } = useAuth();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [clientes, setClientes] = useState<Cliente[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterClienteId, setFilterClienteId] = useState("");
  const [filterStatus, setFilterStatus] = useState<Task['status'] | "all">("all");
  const [showFilters, setShowFilters] = useState(false);
  
  const [taskForm, setTaskForm] = useState({
    title: "",
    description: "",
    date: format(new Date(), "yyyy-MM-dd"),
    cliente_id: "",
    status: "pending" as Task['status']
  });

  const [toast, setToast] = useState<{ message: string; type: "success" | "error" } | null>(null);

  useEffect(() => {
    const fetchTasks = async () => {
      const { data, error } = await supabase
        .from('tasks')
        .select('*')
        .order('date', { ascending: true });
      
      if (!error && data) {
        setTasks(data as Task[]);
      }
    };

    const fetchClientes = async () => {
      const { data, error } = await supabase
        .from('clientes')
        .select('*')
        .order('nome_cliente', { ascending: true });
      
      if (!error && data) {
        setClientes(data as Cliente[]);
      }
    };

    fetchTasks();
    fetchClientes();

    // Subscribe to changes
    const tasksSubscription = supabase
      .channel('tasks-changes')
      .on('postgres_changes', { event: '*', table: 'tasks' }, () => {
        fetchTasks();
      })
      .subscribe();

    const clientesSubscription = supabase
      .channel('clientes-changes')
      .on('postgres_changes', { event: '*', table: 'clientes' }, () => {
        fetchClientes();
      })
      .subscribe();

    return () => {
      tasksSubscription.unsubscribe();
      clientesSubscription.unsubscribe();
    };
  }, []);

  const handleOpenModal = (task: Task | null = null) => {
    if (task) {
      setEditingTask(task);
      setTaskForm({
        title: task.title,
        description: task.description || "",
        date: safeToInputDate(task.date),  // ✅ Normaliza para yyyy-MM-dd
        cliente_id: task.cliente_id,
        status: task.status
      });
    } else {
      setEditingTask(null);
      setTaskForm({
        title: "",
        description: "",
        date: format(new Date(), "yyyy-MM-dd"),
        cliente_id: "",
        status: "pending"
      });
    }
    setIsModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!taskForm.title || !taskForm.cliente_id || !taskForm.date) return;

    try {
      if (editingTask) {
        const { error } = await supabase
          .from('tasks')
          .update({
            ...taskForm,
            updated_at: new Date().toISOString()
          })
          .eq('id', editingTask.id);
        
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('tasks')
          .insert([{
            ...taskForm,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString()
          }]);
        
        if (error) throw error;
      }
      setIsModalOpen(false);
      setToast({ message: `Tarefa ${editingTask ? 'atualizada' : 'criada'} com sucesso!`, type: "success" });
      if (user) {
        logActivity({
          userId: user.uid,
          action: editingTask ? 'update' : 'create',
          entity: 'task',
          entityId: editingTask?.id || 'new',
          entityName: taskForm.title,
        });
      }
    } catch (error) {
      console.error("Erro ao salvar tarefa:", error);
      setToast({ message: "Erro ao salvar tarefa", type: "error" });
    }
  };

  const updateTaskStatus = async (taskId: string, newStatus: Task['status']) => {
    try {
      const { error } = await supabase
        .from('tasks')
        .update({
          status: newStatus,
          updated_at: new Date().toISOString()
        })
        .eq('id', taskId);
      
      if (error) throw error;
      setToast({ message: "Status atualizado!", type: "success" });
    } catch (error) {
      console.error("Erro ao atualizar status:", error);
      setToast({ message: "Erro ao atualizar status", type: "error" });
    }
  };

  const deleteTask = async (id: string) => {
    if (!confirm("Tem certeza que deseja excluir esta tarefa?")) return;
    try {
      const { error } = await supabase
        .from('tasks')
        .delete()
        .eq('id', id);
      
      if (error) throw error;
      setToast({ message: "Tarefa excluída!", type: "success" });
      if (user) {
        const task = tasks.find(t => t.id === id);
        logActivity({
          userId: user.uid,
          action: 'delete',
          entity: 'task',
          entityId: id,
          entityName: task?.title || 'Tarefa',
        });
      }
    } catch (error) {
      console.error("Erro ao excluir tarefa:", error);
      setToast({ message: "Erro ao excluir tarefa", type: "error" });
    }
  };

  const isOverdue = (task: Task) => {
    if (task.status === 'completed' || !task.date) return false;
    try { return isPast(parseISO(task.date + 'T23:59:59')); } catch { return false; }
  };

  const filteredTasks = tasks.filter(task => {
    const matchesSearch = task.title?.toLowerCase().includes(searchTerm.toLowerCase()) || 
                         task.description?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCliente = filterClienteId === "" || task.cliente_id === filterClienteId;
    const matchesStatus = filterStatus === "all" || task.status === filterStatus;
    return matchesSearch && matchesCliente && matchesStatus;
  });

  const activeFilters = (filterClienteId ? 1 : 0) + (filterStatus !== "all" ? 1 : 0);

  const getClienteName = (id: string) => {
    return clientes.find(c => c.id === id)?.nome_cliente || "Cliente não encontrado";
  };

  const columns: { id: Task['status']; title: string; color: string }[] = [
    { id: 'pending', title: 'Pendente', color: 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400' },
    { id: 'in_progress', title: 'Em Andamento', color: 'bg-amber-50 dark:bg-amber-900/20 text-amber-600 dark:text-amber-400' },
    { id: 'completed', title: 'Concluído', color: 'bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-400' }
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Quadro de Tarefas</h1>
          <p className="text-slate-500 dark:text-slate-400">Gerencie seu fluxo de trabalho em formato Kanban</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              placeholder="Buscar..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-9 pr-4 py-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
            />
          </div>
          <button
            onClick={() => setShowFilters(!showFilters)}
            className={cn(
              "flex items-center gap-2 px-3 py-2 rounded-lg border text-sm font-bold transition-all",
              showFilters || activeFilters > 0
                ? "bg-indigo-600 text-white border-indigo-600 shadow-lg shadow-indigo-500/20"
                : "bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400"
            )}
          >
            <Filter className="w-4 h-4" />
            Filtros
            {activeFilters > 0 && (
              <span className="bg-white/30 text-white text-[10px] font-black px-1.5 py-0.5 rounded-full">
                {activeFilters}
              </span>
            )}
          </button>
          <button
            onClick={() => handleOpenModal()}
            className="hidden md:flex items-center justify-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg transition-colors font-medium shadow-lg shadow-indigo-200 dark:shadow-none"
          >
            <Plus className="w-5 h-5" />
            Nova Tarefa
          </button>
          {/* Mobile FAB */}
          <button
            onClick={() => handleOpenModal()}
            className="md:hidden fixed bottom-20 right-4 w-14 h-14 bg-indigo-600 text-white rounded-full shadow-2xl flex items-center justify-center z-40 active:scale-95 transition-transform"
          >
            <Plus className="w-7 h-7" />
          </button>
        </div>
      </div>

      {/* Filtros Avançados */}
      <AnimatePresence>
        {showFilters && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 grid grid-cols-1 sm:grid-cols-3 gap-4"
          >
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Cliente</label>
              <select
                value={filterClienteId}
                onChange={(e) => setFilterClienteId(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none"
              >
                <option value="">Todos os clientes</option>
                {clientes.map(c => (
                  <option key={c.id} value={c.id}>{c.nome_cliente}</option>
                ))}
              </select>
            </div>
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Status</label>
              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value as any)}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none"
              >
                <option value="all">Todos os status</option>
                <option value="pending">Pendente</option>
                <option value="in_progress">Em Andamento</option>
                <option value="completed">Concluído</option>
              </select>
            </div>
            <div className="flex items-end">
              <button
                onClick={() => { setFilterClienteId(""); setFilterStatus("all"); }}
                className="w-full py-2 text-sm font-bold text-slate-500 dark:text-slate-400 hover:text-red-500 border border-slate-200 dark:border-slate-700 rounded-xl transition-colors"
              >
                Limpar Filtros
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="flex flex-col lg:flex-row gap-6 overflow-x-auto pb-4 min-h-[600px]">
        {columns.map((column) => (
          <div key={column.id} className="flex-1 min-w-[300px] flex flex-col gap-4">
            <div className={cn("flex items-center justify-between p-3 rounded-xl font-bold text-xs uppercase tracking-widest", column.color)}>
              <div className="flex items-center gap-2">
                <span>{column.title}</span>
                <span className="bg-white/50 dark:bg-black/20 px-2 py-0.5 rounded-full text-[10px]">
                  {filteredTasks.filter(t => t.status === column.id).length}
                </span>
              </div>
            </div>

            <div className="flex-1 space-y-4">
              <AnimatePresence mode="popLayout">
                {filteredTasks
                  .filter(task => task.status === column.id)
                  .map((task) => (
                    <motion.div
                      layout
                      key={task.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, scale: 0.95 }}
                      className={cn(
                        "bg-white dark:bg-slate-900 border rounded-2xl p-4 shadow-sm hover:shadow-md transition-all group",
                        isOverdue(task)
                          ? "border-red-200 dark:border-red-900/50 bg-red-50/30 dark:bg-red-950/10"
                          : "border-slate-200 dark:border-slate-800"
                      )}
                    >
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <div className="flex-1 min-w-0">
                          <h3 className="font-bold text-slate-900 dark:text-white leading-tight">
                            {task.title}
                          </h3>
                          {isOverdue(task) && (
                            <span className="inline-flex items-center gap-1 mt-1 text-[9px] font-black text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-900/20 px-1.5 py-0.5 rounded-md uppercase tracking-wider">
                              <AlertTriangle className="w-2.5 h-2.5" /> Vencida
                            </span>
                          )}
                        </div>
                        <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          <button 
                            onClick={() => handleOpenModal(task)}
                            className="p-1.5 text-slate-400 hover:text-indigo-500 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 rounded-lg transition-colors"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button 
                            onClick={() => deleteTask(task.id)}
                            className="p-1.5 text-slate-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/10 rounded-lg transition-colors"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                      {task.description && (
                        <p className="text-xs text-slate-500 dark:text-slate-400 mb-4 line-clamp-2">
                          {task.description}
                        </p>
                      )}

                      <div className="space-y-3">
                        <div className="flex items-center gap-2 text-[10px] font-bold text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-900/20 px-2 py-1 rounded-lg w-fit">
                          <User className="w-3 h-3" />
                          {getClienteName(task.cliente_id)}
                        </div>

                        <div className="flex items-center justify-between gap-2">
                          <div className="flex items-center gap-1.5 text-[10px] font-medium text-slate-400">
                            <CalendarIcon className="w-3 h-3" />
                            {safeFormatDate(task.date)}
                          </div>

                          <div className="flex items-center gap-1">
                            {column.id !== 'pending' && (
                              <button 
                                onClick={() => updateTaskStatus(task.id, column.id === 'completed' ? 'in_progress' : 'pending')}
                                className="p-1 text-slate-400 hover:text-indigo-500 transition-colors"
                              >
                                <ChevronLeft className="w-4 h-4" />
                              </button>
                            )}
                            {column.id !== 'completed' && (
                              <button 
                                onClick={() => updateTaskStatus(task.id, column.id === 'pending' ? 'in_progress' : 'completed')}
                                className="p-1 text-slate-400 hover:text-indigo-500 transition-colors"
                              >
                                <ChevronRight className="w-4 h-4" />
                              </button>
                            )}
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  ))}
              </AnimatePresence>
            </div>
          </div>
        ))}
      </div>

      {/* Modal Nova/Editar Tarefa */}
      {isModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-950/50 backdrop-blur-sm">
          <div className="bg-white dark:bg-slate-900 w-full max-w-lg rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 animate-in zoom-in-95 duration-200">
            <div className="p-6 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
              <h2 className="text-xl font-bold text-slate-900 dark:text-white">
                {editingTask ? 'Editar Tarefa' : 'Nova Tarefa'}
              </h2>
              <button onClick={() => setIsModalOpen(false)} className="p-2 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg"><X className="w-6 h-6" /></button>
            </div>
            
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-700 dark:text-slate-300">Cliente</label>
                <select
                  required
                  value={taskForm.cliente_id}
                  onChange={(e) => setTaskForm({ ...taskForm, cliente_id: e.target.value })}
                  className="w-full px-4 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all text-slate-900 dark:text-white"
                >
                  <option value="">Selecione um cliente</option>
                  {clientes.map(c => (
                    <option key={c.id} value={c.id}>{c.nome_cliente}</option>
                  ))}
                </select>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-700 dark:text-slate-300">Título / Atividade</label>
                <input
                  type="text"
                  required
                  placeholder="Ex: Reunião de alinhamento..."
                  value={taskForm.title}
                  onChange={(e) => setTaskForm({ ...taskForm, title: e.target.value })}
                  className="w-full px-4 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all text-slate-900 dark:text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-700 dark:text-slate-300">Data</label>
                  <input
                    type="date"
                    required
                    value={taskForm.date}
                    onChange={(e) => setTaskForm({ ...taskForm, date: e.target.value })}
                    className="w-full px-4 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all text-slate-900 dark:text-white"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-700 dark:text-slate-300">Status</label>
                  <select
                    value={taskForm.status}
                    onChange={(e) => setTaskForm({ ...taskForm, status: e.target.value as any })}
                    className="w-full px-4 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all text-slate-900 dark:text-white"
                  >
                    <option value="pending">Pendente</option>
                    <option value="in_progress">Em Andamento</option>
                    <option value="completed">Concluído</option>
                  </select>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-700 dark:text-slate-300">Observações (Opcional)</label>
                <textarea
                  placeholder="Detalhes adicionais..."
                  rows={4}
                  value={taskForm.description}
                  onChange={(e) => setTaskForm({ ...taskForm, description: e.target.value })}
                  className="w-full px-4 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all text-slate-900 dark:text-white resize-none"
                />
              </div>

              <div className="pt-4 flex gap-3">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="flex-1 px-4 py-2 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 font-medium rounded-xl hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-medium rounded-xl transition-colors shadow-lg shadow-indigo-200 dark:shadow-none"
                >
                  {editingTask ? 'Salvar Alterações' : 'Criar Tarefa'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <AnimatePresence>
        {toast && (
          <Toast 
            message={toast.message} 
            type={toast.type} 
            onClose={() => setToast(null)} 
          />
        )}
      </AnimatePresence>
    </div>
  );
}
